﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.Networking;

namespace my
{
    public class Main : MonoBehaviour
    {
        // Start is called before the first frame update
        void Start()
        {
            print("开始");
            //resourcesLoad();
            //ABWWWLoad();
            //LoadAB_TongBu();
            LOAD();
        }

        // Update is called once per frame
        void Update()
        {

        }

        void resourcesLoad()
        {
            GameObject go = Resources.Load<GameObject>("Cube");
            Instantiate(go);
        }

        /// <summary>
        /// 异步加载ab包
        /// </summary>
        void ABWWWLoad()
        {
            StartCoroutine(LoadAB());
        }

        IEnumerator LoadAB()
        {
            print(Application.streamingAssetsPath + "/model");
            UnityWebRequest request =UnityWebRequestAssetBundle.GetAssetBundle(Application.streamingAssetsPath + "/model");
            yield return request.SendWebRequest();

            print((request.downloadHandler as DownloadHandlerAssetBundle));
            AssetBundle asset = (request.downloadHandler as DownloadHandlerAssetBundle).assetBundle;
            GameObject go = asset.LoadAsset<GameObject>("Cube");
            Instantiate(go);

        }

        /// <summary>
        /// 同步加载方式
        /// </summary>
        void LoadAB_TongBu()
        {
            print("同步加载方式");
            AssetBundle ab = AssetBundle.LoadFromMemory(File.ReadAllBytes(Application.streamingAssetsPath + " /model"));
            GameObject go = ab.LoadAsset<GameObject>("Cube");
            Instantiate(go);
        }


        ///-------------------------------下面是专业加载方式-----------------------------------------

        public Dictionary<string, AssetBundle> AssetBundle_list = new Dictionary<string, AssetBundle>();

        void LOAD()
        {
            GameObject go  = loadAssetBundleFiles<GameObject>(Application.streamingAssetsPath, "StandaloneWindows", "model", "Cube");
            Instantiate(go);
        }

        public T loadAssetBundleFiles<T>(string filePath, string manifestBundleName, string abFileName, string prefabFileName) where T : Object
        {
            /**
             * 1.首先从打包路径获取依赖
             * 这里加载的就是生成的同名文件ab
             */
            string path = getManifestFilePath(filePath, manifestBundleName);
            AssetBundle manifestBundle = AssetBundle.LoadFromFile(path);
            /**
             * 2.获取依赖资源列表
             */
            if (manifestBundle != null)
            {
                try
                {
                    AssetBundleManifest manifest = manifestBundle.LoadAsset<AssetBundleManifest>("AssetBundleManifest");//固定加载方式，通过 assetbundle Abs加载Abs.manifest
                    manifestBundle.Unload(false);
                    //获取加载ab的依赖信息，参数为ab名称，如cube.ab
                    string[] dependsFile = manifest.GetAllDependencies(abFileName);
                    if (dependsFile.Length > 0)
                    {
                        //根据获取到的依赖信息加载所有依赖资源ab
                        AssetBundle[] dependsBundle = new AssetBundle[dependsFile.Length];
                        for (int i = 0; i < dependsFile.Length; i++)
                        {
                            string fp = generateAbsoluteFile(filePath, dependsFile[i]);
                            if (AssetBundle_list.ContainsKey(fp) && AssetBundle_list[fp] != null)
                            {
                            }
                            else
                            {
                                dependsBundle[i] = AssetBundle.LoadFromFile(fp);
                                AssetBundle_list[fp] = dependsBundle[i];
                            }
                        }
                    }
                }
                catch
                {

                }

                /**
                 * 3.最后加载ab
                 * 注意这里的LoadAsset的参数是Prefab的名称，无后缀，如cube而非cube.ab或cube.prefab
                 */
                string cur_path = generateAbsoluteFile(filePath, abFileName);
                if (AssetBundle_list.ContainsKey(cur_path) && AssetBundle_list[cur_path] != null)
                {
                }
                else
                {
                    AssetBundle ab = AssetBundle.LoadFromFile(cur_path);
                    AssetBundle_list[cur_path] = ab;
                }

                T go = AssetBundle_list[cur_path].LoadAsset<T>(prefabFileName) as T;
                //ab.Unload(false);
                StartCoroutine(Unload(AssetBundle_list[cur_path]));
                return go;
            }
            return null;
        }

        private string getManifestFilePath(string filePath, string manifestName)
        {
            if (string.IsNullOrEmpty(manifestName))  /*路径*/
            {
                int lastSymbol = filePath.LastIndexOf('/');
                string pathAssetBunldeName = filePath.Substring(lastSymbol);
                return (filePath + pathAssetBunldeName).Trim();
            }
            else  //name
            {
                return filePath + "/" + manifestName;
            }
        }

        private string generateAbsoluteFile(string filePath, string fileName)
        {
            return string.Concat(filePath, "/", fileName).Trim();
        }

        private IEnumerator Unload(AssetBundle ab)
        {
            yield return new WaitForSeconds(1f);
            if (ab != null)
            {
                ab.Unload(false);
            }
        }

    }

}
 